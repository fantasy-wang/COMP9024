#include "Graph.h"
#include "Quack.h"
#include <stdio.h>
#include <string.h>

#define MAX_WORD_NUMBER 1000
#define MAX_LENGTH 100
#define MAX_LOGGEST_PATH_NUM 10000
#define MAX_NEEDED_PATH_NUM 99

int longest_ladder_number = 0;
int longest_ladder[MAX_LOGGEST_PATH_NUM][MAX_WORD_NUMBER];

/*
 * remove one character from str,
 * store the result in tempStr
 */
void removeOneCharacter(char* str, char* tempStr, int index)
{
	strncpy(tempStr, str, index);
	strncpy(tempStr+index, str+index+1, strlen(str)-index-1);
	tempStr[strlen(str)-1]='\0';
	return;
}

/*check whether s1 and s2 differ by one*/
int differByOne(char* s1, char* s2)
{
	int s1Len = strlen(s1);
	int s2Len = strlen(s2);
	int minLen = s1Len < s2Len ? s1Len : s2Len;	
	int maxLen = s1Len + s2Len + 1 - minLen;
	
	/*check 1 conditions*/
	int sameCharacterNumber = 0;
	for(int i = 0; i < minLen; i++)
	{
		if(s1[i] == s2[i])
		{
			sameCharacterNumber += 1;
		}
	}
	
	/*has the same len and one letter different*/
	if(s1Len == s2Len && sameCharacterNumber == s1Len - 1)
	{
		return 1;
	}
	
	/*remove one letter from s1, check whether same as s2*/
	char* tempStr = (char*)malloc(maxLen*sizeof(char));
	for(int i = 0; i < s1Len; i++)
	{
		removeOneCharacter(s1, tempStr, i);
		if(strcmp(tempStr, s2) == 0)
		{
			free(tempStr);
			return 1;
		}
	}
	
	/*remove one letter from s2, check whether same as s1*/
	for(int i = 0; i < s2Len; i++)
	{
		removeOneCharacter(s2, tempStr, i);
		if(strcmp(tempStr, s1) == 0)
		{
			free(tempStr);
			return 1;
		}
	}
	
	/*return false*/
	free(tempStr);
	return 0;
}


/*use topological sort to find longest path in dag*/
int topological_order(Graph graph, int word_num, int* in_degree, int* length)
{
	Quack quack = createQuack();	
	
	//push item with 0-in_degree into quack
	for(int i = 0; i < word_num; i++)
	{
		length[i] = 0;
		if(in_degree[i] == 0)
		{
			qush(i, quack);
			length[i] = 1;
		}
	}
	
	//loop until quack is empty
	while(!isEmptyQuack(quack))
	{
		//get top-item from quack and traverse it's neignbors, decrease neighbors' in_degree
		int topItem = pop(quack);
		for(int i = topItem + 1; i < word_num; i++)
		{
			if(isEdge(newEdge(topItem, i), graph))
			{
				in_degree[i] -= 1;
				length[i] = (length[topItem] + 1) > length[i] ? (length[topItem] + 1) : length[i];

				//push neignbor into quack
				if(in_degree[i] == 0)
				{
					qush(i, quack);
				}
			}
		}
	}
	
	//find longest_len
	int longest_len = length[0];
	for(int i = 1; i < word_num; i++)
	{
		if(length[i] > longest_len)	
		{
			longest_len = length[i];
		}
	}

	destroyQuack(quack);
	return longest_len;
}


/*the path is inverse stored in quack, we need get it from quack and store it in global-variable: longest_ladder*/
void get_path_from_quack(Quack quack)
{
	Quack tempQuack = createQuack();
	
	int longest_ladder_index = 0;
	
	//get item from quack and store it
	int itemIndex = pop(quack);
	longest_ladder[longest_ladder_number][longest_ladder_index++] = itemIndex;
	push(itemIndex, tempQuack);
	while(!isEmptyQuack(quack))
	{
		int itemIndex = pop(quack);
		push(itemIndex, tempQuack);
		longest_ladder[longest_ladder_number][longest_ladder_index++] = itemIndex;
	}
	
	//push path back to quack
	while(!isEmptyQuack(tempQuack))
	{
		push(pop(tempQuack), quack);
	}	

	destroyQuack(tempQuack);
	return;
}


/*to find inverse topological sequence*/
void find_path_dfs(Graph graph, int word_num, int vertex, char (*word)[MAX_LENGTH], int* length, Quack quack)
{
	if(length[vertex] == 1)
	{
		get_path_from_quack(quack);
		longest_ladder_number += 1;
		return;
	}
	for(int i = 0; i < vertex; i++)
	{
		if(isEdge(newEdge(i, vertex), graph) && length[i] == length[vertex] - 1)
		{
			push(i, quack);
			find_path_dfs(graph, word_num, i, word, length, quack);
			pop(quack);
		}
	}
	return;
}

/*display longest path*/
void show_path(int* index, char (*word)[MAX_LENGTH], int longest_len)
{
	int actual_path_num = longest_ladder_number < MAX_NEEDED_PATH_NUM ? longest_ladder_number : MAX_NEEDED_PATH_NUM;
	for(int i = 0; i < actual_path_num; i++)
	{
		int path_id = index[i];
		printf("%2d: %s", i+1, word[longest_ladder[path_id][0]]);
		for(int j = 1; j < longest_len; j++)
		{
			printf(" -> %s", word[longest_ladder[path_id][j]]);
		}
		printf("\n");
	}
	return;
}

/*sort the path lexicographical*/
int* sort_path(int longest_len)
{
	int* index = (int*)malloc((1+longest_ladder_number)*sizeof(int));
	for(int i = 0; i < longest_ladder_number; i++)
	{
		index[i] = i;
	}
	
	
	/*bubble sort*/
	for(int i = 0; i < longest_ladder_number - 1; i++)
	{
		for(int j = 0; j < longest_ladder_number - 1 - i; j++)
		{
			for(int k = 0; k < longest_len; k++)
			{
				//need't swap
				if(longest_ladder[index[j]][k] < longest_ladder[index[j+1]][k])
				{
					break;
				}
				//have to swap
				else if(longest_ladder[index[j]][k] > longest_ladder[index[j+1]][k])
				{
					int temp = index[j+1];
					index[j+1] = index[j];
					index[j] = temp;
					break;
				}
			}
		}
	}

	return index;
}


//find inverse topological sequence with longest path
void find_longest_path(Graph graph, int word_num, int longest_len, char (*word)[MAX_LENGTH], int* length)
{
	//create quack to store path temporary
	Quack quack = createQuack();
	
	for(int i = 0; i < word_num; i++)
	{
		//find item in longest path
		if(length[i] == longest_len)
		{
			//recursively to find former item
			push(i, quack);
			find_path_dfs(graph, word_num, i, word, length, quack);
			pop(quack);
		}
	}
	
	//sort the path lexicographical, index store the path's index in global-variable: longest_ladder
	int* index = sort_path(longest_len);	
	
	//display paths
	show_path(index, word, longest_len);

	destroyQuack(quack);
	free(index);
	return;
}


int main()
{
	
	char word[MAX_WORD_NUMBER][MAX_LENGTH];
	int in_degree[MAX_WORD_NUMBER];
	int word_num = 0;
	
	//get word from stdin
	while(fscanf(stdin, "%s", word[word_num]) != EOF)
	{
		if(word_num > 0 && strcmp(word[word_num-1], word[word_num]) == 0)
		{
			continue;
		}
		word_num += 1;
	}
	
	//no word input, return directly
	if(!word_num)
	{
		return 0;
	}
	
	//display dictionary
	printf("Dictionary\n");
	for(int i = 0; i < word_num; i++)
	{
		printf("%d: %s\n", i, word[i]);
	}
	
	//create new graph
	Graph graph = newGraph(word_num);
	
	//build edge for graph, update in_degree
	for(int i = 0; i < word_num; i++)
	{
		for(int j = i + 1; j < word_num; j++)
		{
			if(differByOne(word[i], word[j]))
			{
				insertEdge(newEdge(i, j), graph);
				in_degree[j] += 1;
			}
		}
	}
	
	//show graph
	printf("Ordered Word Ladder Graph\n");
	showGraph(graph);
	
	//use topological sort to find longest path
	int* length = (int*)malloc(word_num*sizeof(int));
	int longest_ladder_length = topological_order(graph, word_num, in_degree, length);
	printf("Longest ladder length: %d\n", longest_ladder_length);
	printf("Longest ladders:\n");
	
	//use inverse topological sequence to find all longest path, sort it lexicographical
	find_longest_path(graph, word_num, longest_ladder_length, word, length);
	
	//free memory
	freeGraph(graph);
	free(length);
	return 0;
}









